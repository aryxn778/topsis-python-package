def add_numbers(x, y):
    return x + y